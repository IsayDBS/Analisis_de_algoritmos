Balderas Salomon Isay Damar
El programa se ejecuta de la siguiente forma:
python3 Main.py <Tamano del arreglo>
Es de notar que no se pueden crear arreglos de tamanio 1 o menores, el programa no permite recibir esto tipos de numeros, ni tampoco es robusto, es decir, en caso de que reciba una entrada diferente a un numero mayor a 1, inmediatamente termina el programa.
