Programa shell con incrementos shell y Hibbard, despliega un menu y se puede elegir cualesquiera, al momento de terminar shell, se termina el programa, el archivo elementos.txt es el archivo a modificar para tener diferentes arreglos.
Se ejecuto de la sigueinte manera en Ubuntu:
python3 Main.py elementos.txt
